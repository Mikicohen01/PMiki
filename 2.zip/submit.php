<?php
$servername = "localhost"; // הכתובת של השרת
$username = "root"; // שם משתמש ברירת מחדל
$password = ""; // סיסמה ברירת מחדל
$dbname = "my_website_data"; // שם מסד הנתונים שיצרת

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = htmlspecialchars($_POST['firstName']);
    $lastName = htmlspecialchars($_POST['lastName']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);

    // יצירת חיבור למסד הנתונים
    $conn = new mysqli($servername, $username, $password, $dbname);

    // בדיקה אם החיבור הצליח
    if ($conn->connect_error) {
        die("החיבור נכשל: " . $conn->connect_error);
    }

    $sql = "INSERT INTO bets (firstName, lastName, email, phone) VALUES ('$firstName', '$lastName', '$email', '$phone')";

    if ($conn->query($sql) === TRUE) {
        // הפניה לעמוד האישור לאחר שהנתונים נשמרו בהצלחה
        header("Location: success.html");
        exit();
    } else {
        echo "שגיאה: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
